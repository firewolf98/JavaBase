package org.it.svil.animali;

public abstract class Mammiferi extends Animali{

    public Mammiferi() {
        super();
    }

    public Mammiferi(String specie, String nome) {
        super(specie, nome);
    }
}
