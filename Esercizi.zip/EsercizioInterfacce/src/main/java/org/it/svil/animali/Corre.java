package org.it.svil.animali;

public interface Corre {
    void corre();
}
