package org.it.svil.animali;

public interface Striscia {
    void striscia();
}
