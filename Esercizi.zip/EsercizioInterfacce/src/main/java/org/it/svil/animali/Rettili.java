package org.it.svil.animali;

public abstract class Rettili extends Animali{

    public Rettili() {
        super();
    }

    public Rettili(String specie, String nome) {
        super(specie, nome);
    }
}
