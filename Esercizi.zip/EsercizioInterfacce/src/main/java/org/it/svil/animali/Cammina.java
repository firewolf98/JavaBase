package org.it.svil.animali;

public interface Cammina {
    void cammina();
}
