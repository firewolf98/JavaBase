package org.it.svil.model;

public class Magistrale extends Studente{

    public Magistrale(String nome, String cognome, int isee, int annoCorso) {
        super(nome, cognome, isee, annoCorso);
    }
}
