package org.it.svil.model;

public class Triennale extends Studente{

    public Triennale(String nome, String cognome, int isee, int annoCorso) {
        super(nome, cognome, isee, annoCorso);
    }
}
